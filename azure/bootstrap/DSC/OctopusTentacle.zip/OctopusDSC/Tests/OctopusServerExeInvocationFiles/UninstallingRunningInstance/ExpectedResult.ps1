return @(
  "service --stop --console --instance Octopus",
  "service --stop --uninstall --console --instance Octopus",
  "delete-instance --console --instance Octopus"
)
